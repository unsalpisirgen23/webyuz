<?php

namespace Modules\ScrollingPictures\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ScrollingPictures extends Model
{
    use HasFactory;
}
