<div class="section-header">
    <h1>{{$content}}</h1>
</div>