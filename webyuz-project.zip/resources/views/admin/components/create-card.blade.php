@extends("admin.components.base-card")
@section("component-content")

    {!! $slot !!}

@endsection
