@extends("admin.components.base-form-element")
@section("component-content")

    {!! $slot !!}

@endsection
