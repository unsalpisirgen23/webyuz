<table {!!  $class != null ? 'class="'.$class.'"' : null !!}>
    <thead>
    <tr>
        {!!  $th != null ? '<th>'.$th.'</th>' : null !!}
        <th>Başlık 1</th>
        <th>Başlık 2</th>
    </tr>
    </thead>
    <tbody>
    <tr>

        <td>İçerik 1</td>
        <td>İçerik 2</td>
    </tr>

    </tbody>
</table>
