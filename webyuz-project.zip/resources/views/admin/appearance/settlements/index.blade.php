@extends("admin.layouts.app")
@section("style")

@endsection
@section("content")
    <div id="app">
        <section class="section">
            <div class="section-body">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3">


                            <div class="card" style="border: solid 1px #ddd;">
                                <div class="card-header p-0 pl-2" style="min-height: 40px;line-height: 40px;">
                                    <h5 class="m-0">Menüler</h5>
                                </div>
                                <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-12">

                                            </div>
                                        </div>
                                </div>
                            </div>



                            </div>
                            <div class="col-md-9">
nereye
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@section("script")
@endsection
