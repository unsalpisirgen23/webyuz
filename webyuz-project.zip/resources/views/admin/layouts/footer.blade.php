<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; {{date("Y")}} <div class="bullet"></div> Design By <a href="#">Katriyon Teknoloji A.Ş</a>
    </div>
    <div class="footer-right">
        Webyuz.net
    </div>
</footer>
