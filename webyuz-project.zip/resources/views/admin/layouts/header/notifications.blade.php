
<li class="dropdown dropdown-list-toggle notifications"><a href="#" data-toggle="dropdown" class="nav-link notification-toggle nav-link-lg "><i class="far fa-bell"></i></a>
    <div class="dropdown-menu dropdown-list dropdown-menu-right">
        <div class="dropdown-header">Bildirimler
            <div class="float-right">

            </div>
        </div>
        <div class="dropdown-list-content dropdown-list-icons notifications-list">




        </div>
        <div class="dropdown-footer text-center">

        </div>
    </div>
</li>
