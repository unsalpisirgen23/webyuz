<?php

namespace App\System;

class Style
{

}