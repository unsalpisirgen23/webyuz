<?php

namespace App\System\Kernel;

class SiteAuth
{
    public $id;
    public $database_name;
    public $database_id;
    public $sit_id;
    public $site_domain;
    public $site_title;
    public $site_date;
    public $status;
}