<?php

namespace App\Helpers;

class Alert
{

}
