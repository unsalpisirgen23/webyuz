<?php

namespace App;

interface IModule
{
    public function init();
}