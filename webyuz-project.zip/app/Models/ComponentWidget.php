<?php

namespace Modules\ComponentWidgets\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ComponentWidget extends Model
{
    use HasFactory;
}
