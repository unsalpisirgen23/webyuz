
<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="//cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
    <style>
        #form-all-delete{

        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <div id="app">
        <section class="section">
            <?php echo import("admin.components.breadcrumb",['content'=>'Kullanıcılar']); ?>

            <div class="section-body">
                <div class="col-lg-12 col-md-12 col-12 col-sm-12">
                    <div class="card">
                        <div class="card-header">
                                    <h4>Kullanıcılar</h4>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive p-3">
                                <table class="table table-striped mb-0" id="myTable">
                                    <thead>
                                    <tr>
                                        <th style="width: 110px;">
                                            <label style="font-size: 13px;">
                                                <input type="checkbox"  id="select-all" /> Tümünü Seç
                                            </label>
                                        </th>
                                        <th>Ad</th>
                                        <th>Soyad</th>
                                        <th>Durum</th>

                                        <th>İşlemler</th>
                                    </tr>
                                    </thead>
                                    <tbody>
<?php $row = 1; ?>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>

                                            <td>
                                                <label>
                                                    <input type="checkbox" style="width: 18px;" form="form-all-delete" name="all-delete[]" id="foo<?php echo e($user->id); ?>" value="<?php echo e($user->id); ?>">#<?php echo e($row); ?>

                                                </label>
                                            </td>

                                            <td>
                                                <?php echo e($user->name); ?>

                                            </td>

                                            <td>
                                                <?php echo e($user->lastname); ?>

                                            </td>

                                            <td>
                                                <?php echo $user->status == 1 ? '<div class="btn bg-success color="" >Onaylı</div>' : '<div class="btn bg-warning" style="color:#eee">Onaysız</div>'; ?>

                                            </td>



                                            <td>

                                                <a class="btn btn-primary btn-action mr-1"  href="<?php echo e(route('admin.users.edit',$user->id)); ?>" onclick="confirm('Düzenlemek istediğinize emin misiniz?') ? null :event.preventDefault() " title="Düzenle"><i class="fas fa-pencil-alt"></i></a>

                                                <a class="btn btn-info btn-action mr-1" type="button" data-toggle="modal" data-target="#exampleModal-<?php echo e($user->id); ?>" title="Görünütle"><i class="fas fa-eye"></i></a>
                                                <!-- Bu alan ajax yapılacak -->

     <a class="btn btn-danger btn-action" href="" onclick="event.preventDefault();  confirm('ilmek istediğinize eminmisiniz?') ? document.getElementById('user-form-<?php echo e($user->id); ?>').submit() : null " title="Sil"><i class="fas fa-trash"></i></a>
                                                <form id="user-form-<?php echo e($user->id); ?>" action="<?php echo e(route('admin.users.destroy',$user->id)); ?>" method="POST" style="display: none;">
                                                    <?php echo e(csrf_field()); ?>

                                                </form>

                                            </td>
                                        </tr>
                                        <?php $row+=1; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <form action="<?php echo e(route("admin.users.all_delete")); ?>" method="post" id="form-all-delete" class="ml-2">
                                <?php echo csrf_field(); ?>
                                <button type="submit" onclick="confirm('Seçtiğiniz kullanıcılarınız silinecek onaylıyormusunuz?') ? null :event.preventDefault() " class="btn btn-danger" name="btn-all-delete" id="btn-all-delete" >Seçileni Sil</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script"); ?>
    <script src="//cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready( function () {
            $('#myTable').DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.11.3/i18n/tr.json"
                },
                "columnDefs": [ {
                    "targets": 0,
                    "orderable": false
                } ]
            });
        } );
    </script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        <?php if(session("error")): ?>
        Swal.fire({
            position: 'top-end',
            icon: 'error',
            title: '<?php echo e(session("error")); ?>',
            showConfirmButton: false,
            timer: 1500
        })
        <?php endif; ?>
        <?php if(session("success")): ?>
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: '<?php echo e(session("success")); ?>',
            showConfirmButton: false,
            timer: 1500
        })
        <?php endif; ?>
        $('#select-all').click(function(event) {
            if(this.checked) {
                // Iterate each checkbox
                $(':checkbox').each(function() {
                    this.checked = true;
                });
            } else {
                $(':checkbox').each(function() {
                    this.checked = false;
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("app_modal"); ?>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Modal -->
        <div class="modal fade " id="exampleModal-<?php echo e($user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModal-<?php echo e($user->id); ?>" aria-hidden="true">
            <div class="modal-dialog " role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Kullanıcı Detay</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <p>
                                    <img src="<?php echo e(asset("".$user->profile_image)); ?>" alt="" style="width: 80px;height: 80px;border-radius:1%;border:solid 1px #ddd;" />
                                </p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Ad : </strong><?php echo e($user->name); ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Soyad : </strong><?php echo e($user->lastname); ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Kullanıcı Adı : </strong><?php echo e($user->username); ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>E-posta : </strong><?php echo e($user->email); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <a class="btn btn-primary btn-action w-100"  href="<?php echo e(route('admin.users.edit',$user->id)); ?>" title="Düzenle"><i class="fas fa-pencil-alt"></i></a>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webyuz-project\resources\views/admin/users/index.blade.php ENDPATH**/ ?>