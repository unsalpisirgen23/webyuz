
<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="//cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
    <style>
        #form-all-delete{

        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <div class="col-lg-12 col-md-12 col-12 col-sm-12">
        <div class="card">
            <?php echo import("admin.components.breadcrumb",['content'=>'Tema Bileşenleri']); ?>

            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped mb-0" id="myTable">
                        <thead>
                        <tr>
                            <th>Başlık</th>
                            <th>Bileşen</th>
                            <th>Grup</th>
                            <th>İşlemler</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $customFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr style="border-bottom: solid 1px #ddd;min-height: 30px;">

                                <td style="min-height: 30px;padding: 0px;font-size: 16px;">
                                    <?php echo e($customField->component_title); ?>

                                </td>

                                <td style="overflow: hidden;min-height: 30px;padding: 0px;font-size: 16px;">
                                    <?php echo $customField->component_name; ?>

                                </td>

                                <td style="overflow: hidden;min-height: 30px;padding: 0px;font-size: 16px;">
                                    <?php echo $customField->component_group; ?>

                                </td>

                                <td style="min-height: 30px;padding: 0px;width: 200px;">
                                    <a class="btn btn-primary btn-action m-0 ml-4"  href="<?php echo e(route("admin.ComponentWidgets.edit",$customField->id)); ?>" onclick="confirm('Bu düzenlemek istediğinize eminmisiniz?') ? null :event.preventDefault() " title="Düzenle"><i class="fas fa-pencil-alt"></i></a>
                                    <!-- Bu alan ajax yapılacak -->
                                    <a class="btn btn-danger btn-action m-0 ml-4" href="" onclick="event.preventDefault();  confirm('Bu silmek istediğinize eminmisiniz?') ? document.getElementById('page-form-<?php echo e($customField->id); ?>').submit() : null " title="Sil"><i class="fas fa-trash"></i></a>
                                    <form id="page-form-<?php echo e($customField->id); ?>" action="<?php echo e(route("admin.ComponentWidgets.destroy",$customField->id)); ?>" method="POST" style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection("script"); ?>
    <script src="//cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready( function () {
            $('#myTable').DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.11.3/i18n/tr.json"
                },
                "columnDefs": [ {
                    "targets": 0,
                    "orderable": false
                } ]
            });
        } );
    </script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        <?php if(session("error")): ?>
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: '<?php echo e(session("error")); ?>',
            showConfirmButton: false,
            timer: 1500
        })
        <?php endif; ?>
        <?php if(session("success")): ?>
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: '<?php echo e(session("success")); ?>',
            showConfirmButton: false,
            timer: 1500
        })
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webyuz\resources\views/admin/ComponentWidgets/index.blade.php ENDPATH**/ ?>