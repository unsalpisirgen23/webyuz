<section id="cta" class="cta com-<?php echo e($args->component_name); ?> hook-<?php echo e($args->template_hooks_id); ?> com-id-<?php echo e($args->component_widget_id); ?>">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 text-center text-lg-left">
                <?php if(isset($asset->title)): ?>
                <h3><?php echo $asset->title; ?></h3>
                <?php endif; ?>
                <?php if(isset($asset->description)): ?>
                <p><?php echo $asset->description; ?></p>
                <?php endif; ?>
            </div>
            <div class="col-lg-3 cta-btn-container text-center">
                <?php if(isset($asset->button_title)): ?>
                <a class="cta-btn align-middle" href="<?php echo $asset->button_link; ?>"><?php echo e($asset->button_title); ?></a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\webyuz-project\resources\views/template_components/contents/cta-section.blade.php ENDPATH**/ ?>