
<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="//cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
    <style>
        #form-all-delete{

        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>

    <div class="col-lg-12 col-md-12 col-12 col-sm-12">
        <div class="card">
            <div class="card-header">
                <h4>İçerikler</h4>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped mb-0" id="myTable">
                        <thead>
                        <tr>
                            <th>Başlık</th>
                            <th>Kategori</th>
                            <th style="width: 140px;">Yazar</th>
                            <th style="width: 140px;">Durum</th>
                            <th style="width: 150px;">İşlemler</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td>
                                    <?php echo e($post->title); ?>

                                </td>

                                <td>
                                    <?php echo e(\App\Helpers\Category::get_category($post->category_id,"name")); ?>

                                </td>

                                <td>
                                    <a href="<?php echo e(route('admin.users.show',$post->user_id)); ?>" class="font-weight-600"><?php echo e(\App\Helpers\Post::get_user_name($post->user_id)); ?></a>
                                </td>


                                <td>
                                    <?php echo $post->status == 1 ? '<div class="btn bg-success color="" >Onaylı</div>' : '<div class="btn bg-warning" style="color:#eee">Onaysız</div>'; ?>

                                </td>


                                <td>
                                    <a class="btn btn-primary btn-action mr-1" href="<?php echo e(route('admin.posts.edit',$post->id)); ?>" title="Düzenle"><i class="fas fa-pencil-alt"></i></a>
                                    <!-- Bu alan ajax yapılacak -->
                                    <a class="btn btn-danger btn-action" href="" onclick="event.preventDefault(); return confirm('Silmek istediğinize eminmisiniz?') ? document.getElementById('post-form-<?php echo e($post->id); ?>').submit() : null " title="Sil"><i class="fas fa-trash"></i></a>
                                    <form id="post-form-<?php echo e($post->id); ?>" action="<?php echo e(route('admin.posts.destroy',$post->id)); ?>" method="POST" style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection("script"); ?>
    <script src="//cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready( function () {
            $('#myTable').DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.11.3/i18n/tr.json"
                },
                "columnDefs": [ {
                    "targets": 0,
                    "orderable": false
                } ]
            });
        } );
    </script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        <?php if(session("error")): ?>
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: '<?php echo e(session("error")); ?>',
            showConfirmButton: false,
            timer: 1500
        })
        <?php endif; ?>
        <?php if(session("success")): ?>
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: '<?php echo e(session("success")); ?>',
            showConfirmButton: false,
            timer: 1500
        })
        <?php endif; ?>
        $('#select-all').click(function(event) {
            if(this.checked) {
                // Iterate each checkbox
                $(':checkbox').each(function() {
                    this.checked = true;
                });
            } else {
                $(':checkbox').each(function() {
                    this.checked = false;
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webyuz-project\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>