<a <?php echo e($href != null ? 'href='.$href.'' : null); ?>  <?php echo e($route != null ? 'href='.route($route,$params).'' : null); ?>  <?php echo $class != null ? 'class="'.$class.'"' : null; ?> <?php echo e($id != null ? 'id="'.$id.'"' : null); ?>  <?php echo e($onClick != null ? 'onclick="'.$onClick.'"' : null); ?>   <?php echo e($target != null ? 'target="'.$target.'"' : null); ?>

    <?php echo $title != null ? 'title="'.$title.'"' : null; ?>  ><?php echo $slot; ?></a>
<?php /**PATH C:\xampp\htdocs\webyuz\resources\views/admin/components/link.blade.php ENDPATH**/ ?>