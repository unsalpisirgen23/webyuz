
<?php $__env->startSection("content"); ?>
    <?php echo templateHook()->doAction("get_template_widget_group",['action_group'=>"contents"]); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("templates.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webyuz-project\resources\views/templates/index.blade.php ENDPATH**/ ?>