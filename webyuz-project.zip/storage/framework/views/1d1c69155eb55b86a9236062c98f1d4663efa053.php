<section id="topbar"  class="d-flex align-items-center <?php echo e(@$args->component_name); ?>" data-id="<?php echo e(@$args->thcw_id); ?>">
    <div class="container d-flex justify-content-center justify-content-md-between">
        <div class="contact-info d-flex align-items-center">
            <i class="bi bi-envelope d-flex align-items-center"><a href="mailto:<?php echo $settings->site_email; ?>"><?php echo $settings->site_email; ?></a></i>
            <i class="bi bi-phone d-flex align-items-center ms-4"><span><?php echo $settings->site_phone; ?></span></i>
        </div>
        <div class="social-links d-none d-md-flex align-items-center">
            <a href="<?php echo e($settings->site_twitter); ?>" class="twitter"><i class="bi bi-twitter"></i></a>
            <a href="<?php echo $settings->site_facebook; ?>" class="facebook"><i class="bi bi-facebook"></i></a>
            <a href="<?php echo $settings->site_instagram; ?>" class="instagram"><i class="bi bi-instagram"></i></a>
        </div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\webyuz-project\resources\views/template_components/headers/header-top-bar.blade.php ENDPATH**/ ?>