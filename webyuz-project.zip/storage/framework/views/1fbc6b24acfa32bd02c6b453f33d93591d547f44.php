
<?php $__env->startSection("content"); ?>
    <?php echo templateHook()->doAction("get_template_widget_group",['action_group'=>"contents"]); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("templates.".\App\Helpers\Template::isActive().".app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webyuz\resources\views/templates/Flattern/index.blade.php ENDPATH**/ ?>