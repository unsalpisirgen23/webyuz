<div id="app">
    <section class="section">
        <div class="section-body">
            <form action="<?php echo e(route("modules.TemplateHooks.".$route)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <!-- Main Content -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header" >
                                <h4><?php echo e($title); ?></h4>
                            </div>
                            <div class="card-body">
                                <?php echo $slot; ?>

                                <div class="form-group row mb-4">
                                    <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                                    <div class="col-sm-12 col-md-7">
                                        <button class="btn btn-primary btn-block">Ekle</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
</div><?php /**PATH C:\xampp\htdocs\webyuz\Modules/TemplateHooks/views/components/card-form.blade.php ENDPATH**/ ?>